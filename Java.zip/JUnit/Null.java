package JUnit;

public class Null extends Throwable {}
